clc
clear
close all

%% Variables and Limits
num_vars = 18;
Stages = 3;

% m is for module
% m_1 -> 1
% m_2 -> 2
% m_3 -> 3
lb_m = [10 10 10]; 
up_m = [35 35 35];

% Z_s is for Suns Teeth of first 2 planetery
% Z_s1 -> 4
% Z_s2 -> 5
% Z_s3 -> 6
lb_Z_s = [20 20 20];
up_Z_s = [70 70 70];

% Z_p is for Planets Teeth of first 2 planetery
% Z_p1 -> 7
% Z_p2 -> 8
% Z_p3 -> 9
lb_Z_p = [30 30 30];
up_Z_p = [80 80 80];

% Np is number of planets for each stage
% Np_1 -> 10
% Np_2 -> 11
% Np_3 -> 12
lb_Np = [1,1,1];
up_Np = [9,9,9];

% Mode of each stage
% Mode_1 -> 13
% Mode_2 -> 14
% Mode_3 -> 15
lb_Mode = [1,1,1];
up_Mode = [4,4,4];

% Kb is Coefficient for stage width
% Kb_1 -> 16
% Kb_2 -> 17
% Kb_3 -> 18
lb_Kb = [10 10 10];
up_Kb = [40 40 40];

lb = [ lb_m lb_Z_s lb_Z_p lb_Np lb_Mode lb_Kb lb_alpha lb_beta];
ub = [ up_m up_Z_s up_Z_p up_Np up_Mode up_Kb up_alpha up_beta];

%% Options and Constraints
intcon = 1:15;
pop_size = 1e5;
cross_fraction = 0.8;

 options = optimoptions('ga', ...
     'UseParallel',true,...
    'PopulationSize', pop_size, ...
    'MaxGenerations', 1000, ...
    'FunctionTolerance', 1e-6, ...
    'ConstraintTolerance', 1e-6, ...
    'CrossoverFraction', cross_fraction, ...
    'EliteCount', pop_size*0.15, ...
    'PlotFcn', {@gaplotbestf},...
    'Display', 'iter');
   
x_final = zeros(10,18);
fitval_final = zeros(10,2);
m_selection = [1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3 3.25 3.5 3.75 ...
                   4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 9.0 10.0 11.0 ...
                   12.0 13.0 14.0 15.0 16.0 18.0 20.0 22.0 24.0 27.0 30.0];

%% Evolutionary Algorythm and  Storing Solutions

for i = 1:10
    w1 = 0 + 0.1*(i-1);
    w2 = 1 - 0.1*(i-1);

    [x, fval] = ga(@(x) Fit_Fun(x,w1,w2),num_vars,[],[],[],[],lb,ub,@(x) nonlin_con(x),intcon,options);
    
    fitval_final(i,1) = Mass_Calc(x);
    fitval_final(i,2) = Power_Loss_Calc(x);
    x_final(i,:) = [m_selection([x(1:3)]),x(4:18)];
end
%% Checking
first_row = ['m_1' , 'm_2' , 'm_3' , 'Zs_1', 'Zs_2', 'Zs_3', 'Zp_1', 'Zp_2', 'Zp_3','Np_1', 'Np_2', 'Np_3',...
    'Mode_1' , 'Mode_2' , 'Mode_3' , 'Kb_1' , 'Kb_2' , 'Kb_3'];

writecell(first_row, 'x_final.txt', 'Delimiter', ' ');

writematrix(x_final, 'x_final.txt', 'Delimiter', ' ', 'WriteMode', 'append');
