function [c,ceq] = nonlin_con(x)
    Stages = 3;

%--------------------------------------------------------------------------------------------------------
%                                               Inputs
%--------------------------------------------------------------------------------------------------------
    m_selection = [1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3 3.25 3.5 3.75 ...
                   4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 9.0 10.0 11.0 ...
                   12.0 13.0 14.0 15.0 16.0 18.0 20.0 22.0 24.0 27.0 30.0];


    M = m_selection(x(1:3)); % modules
    Z_s = x(4:6); % Suns Teeth
    Z_p = x(7:9); % Planet Teeth
    Np = x(10:12); % Number of Planets
    Mode = x(13:15); % Modes of each Stage
    Kb = x(16:18); % Coefficient of width
    a_on = deg2rad(x(19:21));
    beta_0 = deg2rad(x(22:24));


%--------------------------------------------------------------------------------------------------------
%                                               Useful Variables
%--------------------------------------------------------------------------------------------------------
    M_s = M./cos(beta_0); % Tranverse module for helical 
    Z_r = zeros(Stages,1);
    for i = 1:Stages
        Z_r(i) = Z_s(i) + 2*Z_p(i);% Teeth of Ring
    end
    b =  Kb .* M; % Stage width
    a_os = atan2(tan(a_on), cos(beta_0));
    z = [Z_s(1) Z_p(1) Z_r(1);Z_s(2) Z_p(2) Z_r(2);Z_s(3) Z_p(3) Z_r(3)];

    r_os = zeros(Stages, 3);
    for i = 1:Stages
        r_os(i,:) = z(i,:)*M_s(i)/2;
    end

    i_stages = I_Finder(z,Mode);
    i_ol = 1;
    u = zeros(Stages,1);

    for i = 1:Stages
        i_ol = i_ol*i_stages(i);  
        if i_stages(i) < 1
            u(i) = 1/i_stages(i); 
        else
            u(i) = i_stages(i);
        end
    end

    if i_ol < 1
        u_out = 1/i_ol; 
    else
        u_out = i_ol;
    end
    
    
    [Fu,~] = Forces(Mode,r_os,b,Np,a_os);

    % Coefficients for eq 15-16
    Ko = 1;
    Kv = 1.05;
    Ks = 1;

    C_pf = zeros(Stages,3);
    
    dw = 2*r_os;

    F = b./cos(beta_0);
    
    for i = 1:Stages
        for j = 1:3
             
            kk = max(0.05,0.1*F(i)/dw(i,j));


            if F(i) <= 25.4 

                C_pf(i,j) = kk - 0.025;

            elseif F(i)<=17*25.4
                
                C_pf(i,j) = kk - 0.0375 + 0.0125/25.4*F(i);

            elseif F(i) <= 40 * 25.4
                
                C_pf(i,j) = kk - 0.1109 + 0.0207/25.4*F(i) - 0.000228/25.4^2*F(i)^2;

            end

        end 
    end 

    
    C_ma = zeros(Stages,3);

    for i = 1:Stages
        C_ma(i,:) = 0.127 + 0.0158/25.4*F(i) - 0.0001093/25.4^2*F(i)^2;
    end

    Kh = 1 + (C_pf + 0.8*C_ma);

    Kb = 1;
    Yn = 1;
    Yth = 1;
    Yz = 1;
    Sigma_fp = 301; % N/mm2
    Sigma_hp = 1088 ; %N/mm2
    Zw = 1;
    Zn = 1;
    Zr = 1;

    
    Z_E = 189.85;
    [I_sp1,J1_sp1,J2_sp1] = Geometry_fact(M(1), min(Z_s(1),Z_p(1)), max(Z_s(1),Z_p(1)),a_on(1), beta_0(1) , b(1),0) ;
    [I_sp2,J1_sp2,J2_sp2] = Geometry_fact(M(2), min(Z_s(2),Z_p(2)), max(Z_s(2),Z_p(2)),a_on(2), beta_0(2) , b(2),0) ;
    [I_sp3,J1_sp3,J2_sp3] = Geometry_fact(M(3), min(Z_s(3),Z_p(3)), max(Z_s(3),Z_p(3)),a_on(3), beta_0(3) , b(3),0) ;
    J1 = [J1_sp1 J1_sp2 J1_sp3];
    J2 = [J2_sp1 J2_sp2 J2_sp3];
    I_sp = [I_sp1 I_sp2 I_sp3];

    [I_pr1,~,~] = Geometry_fact(M(1), Z_p(1), Z_r(1) ,a_on(1), beta_0(1) , b(1),1) ;
    [I_pr2,~,~] = Geometry_fact(M(2), Z_p(2), Z_r(2) ,a_on(2), beta_0(2) , b(2),1) ;
    [I_pr3,~,~] = Geometry_fact(M(3), Z_p(3), Z_r(3) ,a_on(3), beta_0(3) , b(3),1) ;
    I_pr = [I_pr1 I_pr2 I_pr3];

    % for equation 23 
    [~,epsilon_a] = Contact_Ratio(Mode,M,z,b,r_os,a_os,beta_0);

%--------------------------------------------------------------------------------------------------------
%                                           Constraints for Equalities
%--------------------------------------------------------------------------------------------------------
    ceq = [];

%--------------------------------------------------------------------------------------------------------
%                                           Constraints for Inequalities
%--------------------------------------------------------------------------------------------------------
    c = zeros(47,1);

    % equation 15
    S_f = 1.56;
    S_h = 1.25 - 0.016;
    
    for i = 1: Stages

        PG = PG_Finder(Z_s(i),Z_p(i));

        c(i) = S_f - b(i).*M_s(i).*J1(i)*Sigma_fp*Yn/ ( Yth * Yz * abs(Fu(i,1))*Ko*Kv*Ks*Kb*Kh(i,PG(1))); % 1 to 3
        c(i+3) = S_f - b(i).*M_s(i).*J2(i)*Sigma_fp*Yn/ ( Yth * Yz * abs(Fu(i,1))*Ko*Kv*Ks*Kb*Kh(i,PG(2))); % 4 to 6

    end



    % equation 16

    for i = 1:Stages
        % 7 to 9
        c(6+i) = S_h - Sigma_hp*Zn*Zw / (Yth * Yz * Z_E * sqrt(abs(Fu(i,1)).*Ko*Kv*Ks.*(max(Kh(i,1),Kh(i,2))*Zr/min(dw(i,1),dw(i,2))/b(i)/I_sp(i)) ) );
        
        if Mode(i) ~= 4
            % 10 to 12
            c(9+i) = S_h -Sigma_hp*Zn*Zw / (Yth * Yz * Z_E * sqrt(abs(Fu(i,3)).*Ko*Kv*Ks.*(max(Kh(i,2),Kh(i,3))*Zr/dw(i,2)/b(i)/I_pr(i)) )) ;
        else
            % 10 to 12
            c(9+i) = -1;
        end
    end
    
    % equation 23
    %for mesh sun-planet
    c(13:15) = 1.2 - epsilon_a(:,1);
    c(16:18) =  epsilon_a(:,1)-2 ;

    for i = 1:Stages
        if Mode(i) ~= 4 %for mesh planet-ring
            % 19 to 21
            c(18+i) = 1.2 - epsilon_a(i,2);
            % 22 to 24
            c(21+i) = epsilon_a(i,2) -2 ;
    
        else    
            c(18+i) = -1;
            c(21+i) = -1;
    
        end
    end

    % equation 33
    for i = 1:3
        % 25 to 27
        c(24+i) = 0.1 - mod( max(Z_s(i),Z_p(i)) , min(Z_s(i),Z_p(i)));
        
        if Mode(i)~=4 % meaning we dont have a ring
            % 28 to 30
            c(27+i) = 0.1 - mod( Z_r(i) , Z_p(i) );
        else

            c(27+i) = -1;
        end
    end


    % equation 35

    c(31) = u_out - 70*1.05;
    c(32) = 70*0.95 - u_out;
    
    % equation 40-42 boundaries for u_out
    
    for i = 1:3

        if Mode(i) ~= 4
            % 33 to 35
            c(32+i) = mod((Z_r(i)+Z_s(i)), Np(i) ) - 0.1; %equation 40

            % c(35+i) = 0.1 - mod( Z_s(i) , N_p(i) ); %equation 42
            c(35+i) = 0.8 - Non_factorizing(Z_r(i), Np(i));% 36 to 38
        else

            c(32+i) = -1;
            c(35+i) = -1;

        end
    end 

    % Constrain for Mode 4 and Constraints for maximum planet number
    for i = 1:Stages
        if Mode(i) == 4
            
            c(38+i) = -1.1 + Np(i);% 39 to 41
            c(41+i) = -1.1 + Np(i);% 42 to 44
        else    

            c(38+i) = 4*M(i) - 2*(r_os(i,1) + r_os(i,2))*sin(pi/Np(i)) + 2*r_os(i,2);
            c(41+i) = 1.9 - Np(i);
        end
    end 

    % equation 21
    % 45 to 47
    for i = 1:Stages
        u_e = max(Z_p(i)/Z_s(i) , Z_s(i)/Z_p(i));
        c(44+i) = 2./(1+2*u_e)./(sin(a_os(i))).^2.*(u_e + sqrt(u_e.^2 + (1-2*u_e).*(sin(a_os(i))).^2)) - min(Z_s(i),Z_p(i)) ; 
    end

end