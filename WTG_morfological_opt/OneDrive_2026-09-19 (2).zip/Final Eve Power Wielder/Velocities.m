function [omega,add_v] = Velocities(Mode,z,r_os,a_os)
    Stages = 3;
    omega1 = 18*pi/30;
    omega = zeros(Stages,4);

    for j = 1:Stages
        if Mode(j) == 1
            omega(j, 1) = 2*omega1*(1 + z(j, 2)/z(j, 1));
            omega(j, 2) = (z(j, 1)/z(j, 2)+2)*omega1;
            omega(j, 3) = 0;
            omega(j, 4) = omega1;
    
            omega1 = omega(j, 1);
    
        elseif Mode(j) == 2
            omega(j, 1) = -(1 + 2*z(j, 2)/z(j, 1))*omega1;
            omega(j, 2) = -(2+z(j, 1)/z(j, 2))*omega1;
            omega(j, 3) = omega1;
            omega(j, 4) = 0;
    
            omega1 = omega(j, 1);
    
        elseif Mode(j) == 3
            omega(j, 1) = 0;
            omega(j, 2) = -omega1 * z(j, 1)/z(j, 2);
            omega(j, 3) = 2*(1+ z(j, 2)/z(j, 1))/(1 + 2*z(j, 2)/z(j, 1))*omega1;
            omega(j, 4) = omega1;
    
            omega1 = omega(j, 3);
    
        elseif Mode(j) == 4
            omega(j, 1) = omega1;
            omega(j, 2) = -z(j, 1)/z(j, 2)*omega1;
    
            omega1 = omega(j, 2);
        end
    end 

    a_ws = a_os;

    % Relative rotational speed
    omega_rel = zeros(Stages, 3);
    for i = 1:Stages
        omega_rel(i,1:3) = omega(i,1:3) - omega(i,4);
    end
    
    % 
    add_v = zeros(Stages, 2);
    for i = 1:Stages
        add_v(i,1) = 2* abs(omega_rel(i,1))*r_os(i,1)*tan(a_ws(i))*cos(a_os(i))/1000;
        add_v(i,2) = 2* abs(omega_rel(i,3))*r_os(i,3)*tan(a_ws(i))*cos(a_os(i))/1000; 
    end
end