function [i_stage] = I_Finder(z,Mode)
    
    Stages = 3;
    i_stage = zeros(Stages, 1);
    
    % Finding the i of every stage based on the Mode of said stage
    for j = 1:Stages
        if Mode(j) == 1 
            % Case 2 (ω3 = 0;  ωin = ω4; ωout = ω1) 
            i_stage(j) = 1/2/(1 + z(j, 2)/z(j, 1));
        elseif Mode(j) == 2
            % Case 4 (ω4 = 0;  ωin = ω3; ωout = ω1) 
            i_stage(j) = 1/ (1 + 2 * z(j, 2)/z(j, 1));
        elseif Mode(j) == 3
            % Case 5 (ω1 = 0;  ωin = ω4; ωout = ω3) 
            i_stage(j) = (1 + 2* z(j, 2)/z(j, 1))/(1 + z(j, 2)/z(j, 1))/2;
        elseif Mode(j) == 4
            % Case 6 (ωin = ω1; ωout = ω2)
            i_stage(j) = z(j, 2)/z(j, 1);
        end
    end

end