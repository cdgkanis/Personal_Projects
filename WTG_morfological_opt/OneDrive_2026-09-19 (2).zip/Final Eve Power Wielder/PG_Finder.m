function [idx] = PG_Finder(Z_s,Z_p)

PG = [Z_s,Z_p];

PG_sorted = sort(PG);

    if PG(1) == PG_sorted(1)
    
        idx = [1,2];
    
    else
    
        idx = [2,1];
    
    end

end