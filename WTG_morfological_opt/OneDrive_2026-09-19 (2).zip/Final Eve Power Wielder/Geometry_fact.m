function [I, J1, J2] = Geometry_fact(m_n, n_1, n_2, Phi_n, Psi, b, int)
    %AGMA 908-B89
%Chapter 3
%-----------------REFERENCED-----------------------------
    
    m_G = n_2 / n_1;
    
    R_1 = n_1/2/cos(Psi);

    R_2 = m_G*R_1;

    Phi = atan2(tan(Phi_n),cos(Psi));

    R_b1 = R_1*cos(Phi);
    R_b2 = R_b1*m_G;

    C_r = (-1)^int*R_1 + R_2;
    Phi_r = acos((R_b2 + (-1)^int*R_b1)/C_r);

    %Pitch (base circle)
    P_b = 2*pi*R_b1/n_1;

    P_N = pi*cos(Phi_n);

    Psi_b = acos(P_N/P_b);

    C_6 = C_r*sin(Phi_r);
    % Addendum radii
    R_o1 = R_1 + 1;

    if int == 1
        R_o2 = R_2 - 1;
    else
        R_o2 = R_2 + 1;
    end
    C_1 = (-1)^int*(C_6 - sqrt(R_o2^2 - R_b2^2));

    C_4 = C_1 + P_b;

    C_5 = sqrt(R_o1^2 - R_b1^2);

    C_2 = C_5 - P_b;
    
    Z = C_5 - C_1;

    %3.1 Contact ratios - 3.2 Minimum Length of the Lines of Contact 

    m_p = Z/P_b;

    F = b / m_n;
    
    nr = m_p - floor(m_p);
    
    if Psi == 0 
        m_F = 0;
        L_min = F;
    else
        P_x = pi/sin(Psi);
        m_F = F/P_x;

        
        na = m_F - floor(m_F);
            
        if 1 - nr < na 
             

            L_min = (m_p * F - (1. - na) * (1. - nr) * P_x) / cos(Psi_b);

        else

            L_min = (m_p * F - na * nr * P_x) / cos(Psi_b);

        end
    end
    % 3.3 Load Sharing Ratio
    if Psi ~= 0 
        if m_F > 1
            m_N = F/L_min;
        else
            m_N = 1.0;
        end
    else
        m_N = 1.0;
    end
    
    % 3.4 Operating Helix Angle

    Psi_r = atan2(tan(Psi_b),cos(Phi_r));
    
    % 3.5 Operating Normal Pressure Angle
    Phi_nr = asin(cos(Psi_b)*sin(Phi_r));


%Chapter 4
%-----------------Pitting Resistance G.F I-----------------------------
    % 4.2 Operating Pitch Diameter
    d = 2*C_r/(m_G + (-1)^int);

    % 4.3 Radii of Curvature of Profiles at Stress Calculation Point
    R_m1 = 0.5*(R_o1 + (-1)^int*(C_r - R_o2));

    if Psi==0 || m_F <=1

        Rho_1 = C_2;
        Rho_2 =  C_6 - Rho_1*(-1)^int;

    else

        Rho_1 = sqrt(R_m1^2 - R_b1^2);
        Rho_2 =  C_6 - Rho_1*(-1)^int;
   
    end

    % 4.4 Helical Overlap Factor 

    if  Psi == 0 || m_F>1

        C_psi = 1;

    elseif m_F <= 1

        Rho_m1 = sqrt(R_m1^2 - R_b1^2);
        Rho_m2 =  C_6 - Rho_m1*(-1)^int;
        C_psi = sqrt(1 - m_F*(1-Rho_m1*Rho_m2*Z/(Rho_1*Rho_2*P_N)) );
    end
    % 4.1 Calculate I

    I = cos(Phi_r)*C_psi^2/((1/Rho_1 + (-1)^int/Rho_2)*d*m_N);

%Chapter 5
%-----------------Pitting Resistance G.F J for Pinion -----------------------------
    
    % 5.1 Virtual Spur Gear
    n = n_1/(cos(Psi))^3;
    r_n = n/2;
    r_nb = r_n*cos(Phi_n);
    r_na = r_n + R_o1 - R_1;

    % 5.2  Pressure Angle at the Load Application Point
    if m_F<=1 && Psi~=0

        r_n2 = r_n * m_G;
        r_nb2 = r_nb * m_G;
        r_na2 = r_n2 + R_o2 - R_2;
        C_n6 = (r_nb2 + r_nb) * tan(Phi_nr);
        C_n1 = C_n6 - sqrt(r_na2 ^ 2 - r_nb2 ^ 2);
        C_n4 = C_n1 + P_N;
        tan_phin_W = C_n4 / r_nb;

    elseif Psi~=0
        
        tan_phin_W = sqrt((r_na/r_nb)^2-1);

    else

        tan_phin_W = C_4/r_nb;

    end
        

    % 5.3 Generating Rack Shift Coefficient

    x = 0;
    D_sn = 0.024;
    x_g = x - D_sn/2/tan(Phi_n);
    s_n = pi/2+2*x_g*tan(Phi_n);

    % 5.4 Load Angle and Load Radius 
    inv_phi_n = tan(Phi_n) - Phi_n;
    inv_phi_np = tan(Phi_n) - Phi_n + s_n/n;

    Phi_nL = tan_phin_W - inv_phi_np;
    
    r_nL = r_nb/cos(Phi_nL);

    % 5.5 Tool Geometry
    n_c = 1e4;
    n_o = n_c/cos(Psi)^3;
    r_no = n_o/2;
    r_nbo = r_no*cos(Phi_n);
    
    R_c = n_c/2;
    s_no = pi/2;
    x_o = (s_no - pi/2)/2/tan(Phi_n);

    R_oc = (n_c+1)/2;
    h_ao = R_oc - R_c - x_o;

    % Concider Rho_ao 
    Rho_ao = 0.1;

    r_no_s = r_no + h_ao + x_o - Rho_ao;

    Phi_ns = acos(r_nbo/r_no_s);

    inv_Phi_ns = tan(Phi_ns)-Phi_ns;

    s_no = pi/2 + 2*x_o*tan(Phi_n);

    inv_Phi_npo = tan(Phi_n) - Phi_n + s_no/n_o;

    Lambda_ns = 2*(inv_Phi_npo - inv_Phi_ns - Rho_ao/r_nbo);

    % 5.6 Generating Pressure Angle
    inv_Phi_n_ddot = inv_phi_n + 2*(x_g+x_o)*tan(Phi_n)/(n+n_o);

    % 5.6.1 Generating Pitch Radii
    Phi_n_ddot = ainv(inv_Phi_n_ddot);

    r_n_ddot = r_n*cos(Phi_n)/cos(Phi_n_ddot);
    r_no_ddot = r_no*cos(Phi_n)/cos(Phi_n_ddot);

    %5.7 Algorithm for Determining the Critical Point
    a_n = pi/4;

    for i = 1:1e2
        mi_no = acos(r_no_ddot*cos(a_n)/r_no_s) - a_n;
    
        K_s = r_no_ddot*sin(a_n) - r_no_s*sin(a_n+mi_no);
    
        K_F = K_s - Rho_ao;
    
        Theta_no = mi_no - Lambda_ns/2 + pi/n_o;
    
        Theta_n = n_o/n*Theta_no;
    
        Beta_n = a_n - Theta_n;
    
        Ksi_nF = r_n_ddot*sin(Theta_n) + K_F*cos(Beta_n);
    
        Htta_nf = r_n_ddot*cos(Theta_n) + K_F*sin(Beta_n);
    
        h_F = r_nL - Htta_nf;
        y = 2 * h_F * tan(Beta_n) - Ksi_nF;
        y_dot = (2 * h_F / cos(Beta_n) ^ 2) - K_F * sin(Beta_n) + n_o/n *( ...
            (r_no_ddot * sin(a_n) / (r_no_s * sin(a_n + mi_no))) - 1) * (...
                    2 * Ksi_nF * tan(Beta_n) - Htta_nf - 2 * h_F / (...
                        cos(Beta_n) ^ 2)) - r_no_ddot * (...
                    cos(a_n) - sin(a_n) / tan(a_n + mi_no)) * ((1 + sin(Beta_n) ^ 2.) / cos(Beta_n));
        
        if  abs(y / y_dot) <1e-4

            break
        else
            a_n = a_n - y / y_dot;
        end
            
    end


    % 5.9 Radius of Curvature of Root Fillet
    K_s = r_no_ddot - r_no_s;
    Rho_f_dot = Rho_ao + K_s^2/( r_n_ddot*r_no_ddot*sin(a_n)/(r_n_ddot+r_no_ddot)-K_s );

    Rho_f = Rho_ao + (r_no_ddot - r_no_s)^2/( r_n_ddot*r_no_ddot/(r_n_ddot+r_no_ddot)-(r_no_ddot - r_no_s) );


    % 5.10 Radius of Curvature of Root Fillet

    if m_F<=1

        C_h = 1;

    else
        omega = rad2deg(atan2(tan(Psi),sin(Phi_n)));
        C_h = 1/( 1 - sqrt(omega/100*(1 - 0.01*omega)) );

    end
    % 5.11 Stress Correction Factor, Kf

    S_f = 2*Ksi_nF;
    H = 0.331 - 0.436*Phi_n;
    L = 0.324 - 0.492*Phi_n;
    M = 0.261 + 0.545*Phi_n;

    K_f = H + (S_f/Rho_f)^L * (S_f/h_F)^M;

    % 5.12 Helix Angle Factor, K_psi

    if m_F<=1

        K_psi = 1;

    else

        K_psi = cos(Psi_r)*cos(Psi);

    end

    Y = K_psi / ( cos(Phi_nL)/cos(Phi_nr) * (6*h_F/S_f^2/C_h - tan(Phi_nL)/S_f) );


    % Bending Strength Geometry Factor, J

    J1 = Y*C_psi/(K_f*m_N);


%-----------------Pitting Resistance G.F J for Gear -----------------------------
    
    % 5.1 Virtual Spur Gear
    n = n_2/(cos(Psi))^3;
    r_n = n/2;
    r_nb = r_n*cos(Phi_n);
    Sub = [R_1,R_2,R_o1,R_o2];
    R_1 = Sub(2);
    R_2 = Sub(1);
    R_o1 = Sub(4);
    R_o2 = Sub(3);
    m_G = 1/m_G;
    

    r_na = r_n + R_o1 - R_1;
    C_4 = C_6 - C_2;

    % 5.2  Pressure Angle at the Load Application Point
    if m_F<=1 && Psi~=0

        r_n2 = r_n * m_G;
        r_nb2 = r_nb * m_G;
        r_na2 = r_n2 + R_o2 - R_2;
        C_n6 = (r_nb2 + r_nb) * tan(Phi_nr);
        C_n1 = C_n6 - sqrt(r_na2 ^ 2 - r_nb2 ^ 2);
        C_n4 = C_n1 + P_N;
        tan_phin_W = C_n4 / r_nb;

    elseif Psi~=0
        
        tan_phin_W = sqrt((r_na/r_nb)^2-1);

    else

        tan_phin_W = C_4/r_nb;

    end
        

    % 5.3 Generating Rack Shift Coefficient

    x = 0;
    D_sn = 0.024;
    x_g = x - D_sn/2/tan(Phi_n);
    s_n = pi/2+2*x_g*tan(Phi_n);

    % 5.4 Load Angle and Load Radius 
    inv_phi_n = tan(Phi_n) - Phi_n;
    inv_phi_np = tan(Phi_n) - Phi_n + s_n/n;

    Phi_nL = tan_phin_W - inv_phi_np;
    
    r_nL = r_nb/cos(Phi_nL);

    % 5.5 Tool Geometry
    n_c = 1e4;
    n_o = n_c/cos(Psi)^3;
    r_no = n_o/2;
    r_nbo = r_no*cos(Phi_n);
    
    R_c = n_c/2;
    s_no = pi/2;
    x_o = (s_no - pi/2)/2/tan(Phi_n);

    R_oc = (n_c+1)/2;
    h_ao = R_oc - R_c - x_o;

    % Concider Rho_ao 
    Rho_ao = 0.25;
    r_no_s = r_no + h_ao + x_o - Rho_ao;

    Phi_ns = acos(r_nbo/r_no_s);

    inv_Phi_ns = tan(Phi_ns)-Phi_ns;

    s_no = pi/2 + 2*x_o*tan(Phi_n);

    inv_Phi_npo = tan(Phi_n) - Phi_n + s_no/n_o;

    Lambda_ns = 2*(inv_Phi_npo - inv_Phi_ns - Rho_ao/r_nbo);

    % 5.6 Generating Pressure Angle
    inv_Phi_n_ddot = inv_phi_n + 2*(x_g+x_o)*tan(Phi_n)/(n+n_o);

    % 5.6.1 Generating Pitch Radii
    Phi_n_ddot = ainv(inv_Phi_n_ddot);

    r_n_ddot = r_n*cos(Phi_n)/cos(Phi_n_ddot);
    r_no_ddot = r_no*cos(Phi_n)/cos(Phi_n_ddot);

    %5.7 Algorithm for Determining the Critical Point
    a_n = pi/4;

    for i = 1:1e2
        mi_no = acos(r_no_ddot*cos(a_n)/r_no_s) - a_n;
    
        K_s = r_no_ddot*sin(a_n) - r_no_s*sin(a_n+mi_no);
    
        K_F = K_s - Rho_ao;
    
        Theta_no = mi_no - Lambda_ns/2 + pi/n_o;
    
        Theta_n = n_o/n*Theta_no;
    
        Beta_n = a_n - Theta_n;
    
        Ksi_nF = r_n_ddot*sin(Theta_n) + K_F*cos(Beta_n);
    
        Htta_nf = r_n_ddot*cos(Theta_n) + K_F*sin(Beta_n);
    
        h_F = r_nL - Htta_nf;
        y = 2 * h_F * tan(Beta_n) - Ksi_nF;
        y_dot = (2 * h_F / cos(Beta_n) ^ 2) - K_F * sin(Beta_n) + n_o/n *( ...
            (r_no_ddot * sin(a_n) / (r_no_s * sin(a_n + mi_no))) - 1) * (...
                    2 * Ksi_nF * tan(Beta_n) - Htta_nf - 2 * h_F / (...
                        cos(Beta_n) ^ 2)) - r_no_ddot * (...
                    cos(a_n) - sin(a_n) / tan(a_n + mi_no)) * ((1 + sin(Beta_n) ^ 2.) / cos(Beta_n));
        
        if  abs(y / y_dot) <1e-4

            break
        else
            a_n = a_n - y / y_dot;
        end
            
    end


    % 5.9 Radius of Curvature of Root Fillet
    K_s = r_no_ddot - r_no_s;
    Rho_f_dot = Rho_ao + K_s^2/( r_n_ddot*r_no_ddot*sin(a_n)/(r_n_ddot+r_no_ddot)-K_s );

    Rho_f = Rho_ao + (r_no_ddot - r_no_s)^2/( r_n_ddot*r_no_ddot/(r_n_ddot+r_no_ddot)-(r_no_ddot - r_no_s) );


    % 5.10 Radius of Curvature of Root Fillet

    if m_F<=1

        C_h = 1;

    else
        omega = rad2deg(atan2(tan(Psi),sin(Phi_n)));
        C_h = 1/( 1 - sqrt(omega/100*(1 - 0.01*omega)) );

    end
    % 5.11 Stress Correction Factor, Kf

    S_f = 2*Ksi_nF;
    H = 0.331 - 0.436*Phi_n;
    L = 0.324 - 0.492*Phi_n;
    M = 0.261 + 0.545*Phi_n;

    K_f = H + (S_f/Rho_f)^L * (S_f/h_F)^M;

    % 5.12 Helix Angle Factor, K_psi

    if m_F<=1

        K_psi = 1;

    else

        K_psi = cos(Psi_r)*cos(Psi);

    end

    Y = K_psi / ( cos(Phi_nL)/cos(Phi_nr) * (6*h_F/S_f^2/C_h - tan(Phi_nL)/S_f) );


    % Bending Strength Geometry Factor, J

    J2 = Y*C_psi/(K_f*m_N);

end

function k = ainv(x)
    y = @(k) tan(k) - k - x;
    k_0 = sqrt(2*x);

    k = fzero(y,k_0);
end