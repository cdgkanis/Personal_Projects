function [f] = Fit_Fun(x,P_in)
    
%------------------- Passing x -------------------------

    m_selection = [1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3 3.25 3.5 3.75 ...
                   4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 9.0 10.0 11.0 ...
                   12.0 13.0 14.0 15.0 16.0 18.0 20.0 22.0 24.0 27.0 30.0];


    M = m_selection(x(1:3)); % modules
    Z_s = x(4:6); % Suns Teeth
    Z_p = x(7:9); % Planet Teeth
    Np = x(10:12); % Number of Planets
    Mode = x(13:15); % Modes of each Stage
    Kb = x(16:18); % Coefficient of width
    a_on = deg2rad(x(19:21));
    beta_0 = deg2rad(x(22:24));

%-------------- Computing Variables through x -----------
    
    M_s = M./cos(beta_0); % Tranverse module for helical 
    Z_r = Z_s + 2*Z_p; % Teeth of Ring
    b =  Kb .* M; % Stage width
    
    z = [Z_s(1) Z_p(1) Z_r(1);Z_s(2) Z_p(2) Z_r(2);Z_s(3) Z_p(3) Z_r(3)];
%------------------- Calling Mass Function -------------
    w1 = 0.6; % weight for Mass Function
    Mass = Mass_Calc(Mode, M_s, z, b, Np); % Mass Loss Function

%----------------- Calling Power Loss Function ---------
    
    w2 = 0.4; % weight for Power Loss Function
    Power_Loss = Power_Loss_Calc(M,z,Mode,b,a_on,beta_0,Np,P_in); %Power Loss Function

%----------------- Defining Fitness Function ---------   
    f = w1*Mass/1e3 + w2*Power_Loss/1e4;

end
