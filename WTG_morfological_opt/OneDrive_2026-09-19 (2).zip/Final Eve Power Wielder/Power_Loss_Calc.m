function [P_losses] = Power_Loss_Calc(m,z,Mode,b,a_on,beta_0,N_p,P_in)

%--------------------------------------------------------------------------------------------------------
%                                                Useful Vriables
%--------------------------------------------------------------------------------------------------------
  
    Stages = 3;
    
    m_s = m./cos(beta_0);
    a_os = atan2(tan(a_on), cos(beta_0));
    a_ws = a_os; 
    
    r_os= zeros(Stages, 3);
    for i = 1:Stages
        r_os(i,:) = z(i,:)*m_s(i)/2;
    end
    
%--------------------------------------------------------------------------------------------------------
%                                               Calling Functions
%--------------------------------------------------------------------------------------------------------
    
    [ ~ , F_b] = Forces(Mode,r_os,b,N_p,a_os,P_in);

    [ ~ , add_v] = Velocities(Mode,z,r_os,a_os);

    [epsilon_i,epsilon_a] = Contact_Ratio(Mode,m,z,b,r_os,a_os,beta_0);
%--------------------------------------------------------------------------------------------------------
%                                               Curvature Radius
%--------------------------------------------------------------------------------------------------------
  
    ro_redC = zeros(Stages, 2);
    beta_b = zeros(Stages, 1);
    
    for i =1:Stages
        beta_b(i) = atan(cos(a_ws(i))*tan(beta_0(i)));
    end
    
    for i = 1:Stages 
        ro_redC(i,1) = m_s(i)*z(i,1)*z(i,2)/(z(i,1) + z(i,2))*sin(a_ws(i))/cos(beta_b(i))/1000/2;
        if Mode(i) ~= 4
            ro_redC(i,2) = -m_s(i)*z(i,2)*z(i,3)/(z(i,2) - z(i,3))*sin(a_ws(i))/cos(beta_b(i))/1000/2;
        end
    end

%--------------------------------------------------------------------------------------------------------
%                                    Values of the Problem           
%--------------------------------------------------------------------------------------------------------

    % %mew_mz
    % Ra_1 = 0.5e-6;%surface roughness
    % Ra_2 = 0.7e-6;
    % 

    htta = 15.575;%[mPa*s]
    Ra = 0.7e-6;

    %X_L ,for d = 0.0651 mineral oil
    X_L = zeros(Stages,2);
    X_L = 1./F_b.^(0.0651);
    

%--------------------------------------------------------------------------------------------------------
%                                           Power Loss         
%--------------------------------------------------------------------------------------------------------
    
    mew_mz = zeros(Stages, 2);
    for i = 1:Stages
        mew_mz(i,1) = 0.048*(F_b(i,1)/add_v(i,1)/ro_redC(i,1))^0.2*Ra^0.25*X_L(i,1)*htta^(-0.05);
        if Mode(i) ~= 4
            mew_mz(i,2) = 0.048*(F_b(i,2)/add_v(i,2)/ro_redC(i,2))^0.2*Ra^0.25*X_L(i,2)*htta^(-0.05);
        end
    end

    %{
    K_o = zeros(Stages,2);
    for i = 1:Stages
        for j = 1:2
            m = 2*j - 1;
            if Mode(i) ==4 && j == 2
                K_o(i, j) = 0;
            else
                K_o(i, j) = 1/epsilon_a(i,j)*epsilon_i(i,m);
            end
        end
    end
    K_o

    Lm = zeros(Stages,2);
    for i = 1:Stages
        for j = 1:2
            z_p = min([z(i,j) z(i,j+1)]);
            Lm(i,j) = (2*K_o(i, j)^2 - 2*K_o(i, j) + 1)/( 1 - mew_mz(i,j)/cos(beta_b(i))*( tan(a_ws(i))*(2*K_o(i,j) - 1) - pi/z_p*epsilon_a(i,j)*(2*K_o(i, j)^2 - 2*K_o(i, j) + 1)) );
        end
    end

    Hv = zeros(Stages,2);
    for i = 1:Stages
        [z_p] = min([z(i,1) z(i,2)]);
        [z_w] = max([z(i,1) z(i,2)]);
        Hv(i,1) = (1/z(i,1) + 1/z(i,2))*pi/cos(beta_b(i))*epsilon_a(i,1)*Lm(i,1);
        if Mode(i) ~= 4
            Hv(i,2) = (1/z(i,2) - 1/z(i,3))*pi/cos(beta_b(i))*epsilon_a(i,2)*Lm(i,2);
        end
    end
    Hv
    %}
    Hv_ohlendorf = zeros(3,2);
    for i = 1:3
        Hv_ohlendorf(i,1) = (1/z(i,1) + 1/z(i,2))*pi/cos(beta_b(i))*(1 - epsilon_a(i,1) + epsilon_i(i,1)^2 + epsilon_i(i,2)^2);
        if Mode(i) ~= 4
            Hv_ohlendorf(i,2) = ((z(i,3)+z(i,2))/z(i,2)^2)*pi/cos(beta_b(i))*(1 - epsilon_a(i,2) + epsilon_i(i,2)^2 + epsilon_i(i,3)^2);
        else
            Hv_ohlendorf(i,2) = 0;
        end
    end
    

    Gb = zeros(Stages,2);
    P_through = P_in;
    for i = 1:Stages
        Gb(i,1) = P_through*mew_mz(i,1)*Hv_ohlendorf(i,1);
        
        if Mode(i) ~= 4
            Gb(i,2) = P_through*mew_mz(i,2)*Hv_ohlendorf(i,2);
        end
        P_through = P_through - Gb(i,1) - Gb(i,2);
    end

    P_losses = P_in - P_through;
end