function [epsilon_i,epsilon_a] = Contact_Ratio(Mode,m,z,b,r_os,a_os,beta_0)
    
    Stages = 3;
    a_ws = a_os;
    
    Db = zeros(Stages, 3);
    for i = 1:Stages
        for j = 1:3
            Db(i,j) = 2*r_os(i,j)*cos(a_os(i));
        end
    end
    
    C_h = ones(Stages,1); % ( head Coeficient) height of the tooth as a persentage of the module on the normal plain 

    Dt = zeros(Stages, 3);
    for i = 1:3
        for j = 1:2
            Dt(i,j) = 2*r_os(i,j) + 2*C_h(i)*m(i);
        end
        if Mode(i) ~= 4 
            Dt(i,3) = 2*r_os(i,3) - 2*C_h(i)*m(i);
        end
    end

    epsilon_i = zeros(Stages,3);
    for i = 1:Stages 
        for j = 1:2
            epsilon_i(i,j) = z(i,j)/2/pi*(sqrt((Dt(i,j)/Db(i,j))^2 - 1) - tan(a_ws(i)));
        end
        if Mode(i) ~= 4
            epsilon_i(i,3) = z(i,3)/2/pi*(tan(a_ws(i)) - sqrt((Dt(i,3)/Db(i,3))^2 - 1) );
        end
     end    
    
    epsilon_a = zeros(Stages, 2);
    
    for i = 1:Stages
        epsilon_a(i,1) = epsilon_i(i,1) + epsilon_i(i,2);
        if Mode(i) ~= 4
            epsilon_a(i,2) = epsilon_i(i,2) + epsilon_i(i,3);
        end
    end
    
    epsilon_sp = zeros(Stages, 1);
    for i = 1:3 
        epsilon_sp(i) = b(i)*sin(beta_0(i))/pi./m(i);
    end

    epsilon = zeros(Stages,2);
    for i = 1:3
        epsilon(i,1) = epsilon_a(i, 1) + epsilon_sp(i);
        if Mode(i) ~= 4
            epsilon(i,2) = epsilon_a(i, 2) + epsilon_sp(i);
        end
    end
end