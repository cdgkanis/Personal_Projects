function Mass = Mass_Calc(Mode, m_s, z, b, N_cp)
    
    Stages = 3;

    % Radii

    r_os= zeros(Stages, 3);
    for i = 1:Stages
        r_os(i,:) = z(i,:)*m_s(i)/2;
    end
    d_ro(:) = 2*r_os(:,3) + 7*m_s(:);

    V = 0;
    for i = 1:Stages
        V = V + pi*r_os(i,1)^2*b(i);
        V = V + pi*r_os(i,2)^2*b(i)*N_cp(i);
        if Mode(i) ~= 4
            V = V + pi*( d_ro(i)^2/4 - r_os(i,3)^2 )*b(i);
        end
    end
    d = 7.8e-6;%density of gears
    Mass = V*d;

end