function [per] = Non_factorizing(Zr,N_cp)
    Q = Zr/N_cp;

    if Q - floor(Q)== 0
        per = 0; % %factorized
    else
        y = 1/(Q - floor(Q));

        if mod(y, 1) == 0 
            N_Gp = N_cp/y;
            per = 1/N_Gp;
        else
            per = 1;
        end
    end
end