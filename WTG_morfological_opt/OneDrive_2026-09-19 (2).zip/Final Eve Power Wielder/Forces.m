function [Fu,F_b] = Forces(Mode,r_os,b,N_p,a_os,P_in)
    Stages = 3;

    Fu = zeros(Stages,4);
    
    omega_in = 18*pi/30;
    
    M_in = P_in/omega_in;
    
    %For 2 level application [AGMA 6123-c16 2016]
    K_share_Load = [1.00 1.00 1.05 1.25 1.35 1.44 1.47 1.52 1.61];
    
    Correction = zeros(Stages,1);
    for i = 1:Stages
        Correction(i) = K_share_Load(N_p(i))/N_p(i);
    end

    for i = 1:Stages
        
       if Mode(i) == 1
            Fu(i,4) = M_in/(r_os(i,1)+r_os(i,2))*Correction(i)*1000;
    
            Fu(i,2) = Fu(i,4)/2; 
            Fu(i,3) = Fu(i,4)/2; 
    
            Fu(i,1) = Fu(i,4)/2; 
            M_in = Fu(i,1)*r_os(i,1)/Correction(i)/1000;
        elseif Mode(i) == 2
            Fu(i,3) = M_in/r_os(i,3)*Correction(i)*1000;
     
            Fu(i,2) = Fu(i,3); 
            Fu(i,4) = 2*Fu(i,3);
    
            Fu(i,1) = Fu(i,3);
            M_in = Fu(i,1)*r_os(i,1)/Correction(i)/1000;
        elseif Mode(i) == 3
            Fu(i,4) = M_in/(r_os(i,1)+r_os(i,2))*Correction(i)*1000;
    
            Fu(i,1) = Fu(i,4)/2; 
            Fu(i,2) = Fu(i,4)/2; 
    
            Fu(i,3) = Fu(i,4)/2;
            M_in = Fu(i,3)*r_os(i,3)/Correction(i)/1000;
        elseif Mode(i) == 4 
            Fu(i, 1) = M_in/r_os(i,1)*Correction(i)*1000;
            Fu(i, 2) = Fu(i, 1);
    
            M_in = Fu(i,2)*r_os(i,2)/Correction(i)/1000;
        end
    end

    F_tb = zeros(Stages, 2);
    for i = 1:Stages 
        F_tb(i,1:2) = Fu(i,1:2) / cos(a_os(i));
    end
    


    F_b = zeros(Stages, 2);
    for i = 1:Stages
        F_b(i, 1:2) = F_tb(i, 1:2)/ b(i)*1000;
    end
end